# Archita Portfolio
Built using HTML & Tailwind CSS.